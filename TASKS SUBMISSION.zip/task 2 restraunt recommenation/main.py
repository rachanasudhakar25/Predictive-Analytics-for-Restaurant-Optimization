import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load the dataset
data = pd.read_csv('Dataset .csv')

# Preprocess the dataset (Handle missing values)
data['Cuisines'] = data['Cuisines'].fillna('Unknown')
data['City'] = data['City'].fillna('Unknown')
data['Aggregate rating'] = data['Aggregate rating'].fillna(data['Aggregate rating'].mean())

# Encode categorical columns (like City, Cuisines, Currency)
data = pd.get_dummies(data, columns=['Currency'], drop_first=True)

# Combine features for recommendation
data['Combined_Features'] = data['Restaurant Name'] + ' ' + data['Cuisines'] + ' ' + data['City'] + ' ' + data['Average Cost for two'].astype(str)

# Function to get user preferences
def get_user_preferences():
    user_cuisine = input("Enter your preferred cuisine: ")
    user_price_range = int(input("Enter your preferred price range (1-4): "))
    user_city = input("Enter your preferred city: ")
    return user_cuisine, user_price_range, user_city

# Get user preferences and filter data
user_cuisine_preference, user_price_range, user_city_preference = get_user_preferences()

# Filter before encoding (for proper text-based operations)
filtered_data = data[data['Cuisines'].str.contains(user_cuisine_preference, case=False)]
filtered_data = filtered_data[filtered_data['Price range'] == user_price_range]
filtered_data = filtered_data[filtered_data['City'].str.contains(user_city_preference, case=False)]

# Check if filtered data is empty
if filtered_data.empty:
    print("No matching restaurants found for your preferences. Please try again with different preferences.")
else:
    # Create TF-IDF vectorizer for text-based similarity
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(filtered_data['Combined_Features'])

    # Calculate similarity scores
    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

    # Function to get top N recommendations
    def get_top_recommendations(index, cosine_sim, n=5):
        similarity_scores = list(enumerate(cosine_sim[index]))
        sorted_scores = sorted(similarity_scores, key=lambda x: x[1], reverse=True)
        top_recommendations = sorted_scores[1:n+1]  # Exclude the first one (itself)
        return top_recommendations

    # Example usage to get recommendations for a restaurant (say index 0)
    top_recommendations = get_top_recommendations(0, cosine_sim)

    # Print recommendations
    for idx, score in top_recommendations:
        print(f"Recommended Restaurant: {filtered_data['Restaurant Name'].iloc[idx]} with similarity score: {score:.4f}")
